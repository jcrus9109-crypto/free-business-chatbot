export async function sendMessage(message) {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": "Bearer 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",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: message }]
    })
  });
  if (!response.ok) throw new Error("API Error");
  const data = await response.json();
  return data.choices[0]?.message?.content || "No response";
}