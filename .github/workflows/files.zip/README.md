# AI Chatbot

A simple React web app for chatting with OpenAI’s API.

## Setup

```bash
npm install
npm run dev
```

## API KEY

**Warning:** Your API key is hardcoded for demo/testing. For production, use environment variables/serverless backend.

## Deploy

You can deploy on Vercel, Netlify, or any static host.