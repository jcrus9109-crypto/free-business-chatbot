import React, { useState } from "react";
import { sendMessage } from "./api";

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSend(e) {
    e.preventDefault();
    if (!input.trim()) return;
    setLoading(true);
    setMessages([...messages, { role: "user", content: input }]);
    try {
      const reply = await sendMessage(input);
      setMessages(msgs => [...msgs, { role: "assistant", content: reply }]);
    } catch {
      setMessages(msgs => [...msgs, { role: "assistant", content: "Error communicating with API." }]);
    }
    setInput("");
    setLoading(false);
  }

  return (
    <main style={{ maxWidth: 500, margin: "2rem auto", fontFamily: "sans-serif" }}>
      <h1>AI Chatbot</h1>
      <div style={{ minHeight: 300, border: "1px solid #eee", padding: 10, marginBottom: 10 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ textAlign: msg.role === "user" ? "right" : "left", margin: "10px 0" }}>
            <b>{msg.role === "user" ? "You" : "Bot"}:</b> {msg.content}
          </div>
        ))}
        {loading && <div>Bot is thinking...</div>}
      </div>
      <form onSubmit={handleSend} style={{ display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Type your message..."
          style={{ flex: 1, padding: 8 }}
          disabled={loading}
        />
        <button type="submit" disabled={loading}>Send</button>
      </form>
    </main>
  );
}